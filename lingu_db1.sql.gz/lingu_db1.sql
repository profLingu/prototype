-- Adminer 4.6.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `li_articles`;
CREATE TABLE `li_articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permalink` varchar(160) NOT NULL,
  `datetime` datetime NOT NULL,
  `title` varchar(160) NOT NULL,
  `text` text NOT NULL,
  `category` int(11) NOT NULL,
  `by` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `upby` int(11) DEFAULT NULL,
  `upat` datetime DEFAULT NULL,
  `views` int(11) DEFAULT 0,
  `tags` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permalink` (`permalink`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `li_articles` (`id`, `permalink`, `datetime`, `title`, `text`, `category`, `by`, `status`, `upby`, `upat`, `views`, `tags`) VALUES
(1,	'halodunia',	'2018-10-05 19:39:19',	'Halo Dunia!',	'Ini adalah postingan pertama.',	1,	1,	1,	NULL,	NULL,	0,	'tag');

DROP TABLE IF EXISTS `li_categories`;
CREATE TABLE `li_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `permalink` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permalink` (`permalink`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `li_categories` (`id`, `name`, `permalink`) VALUES
(1,	'Uncategorized',	'uncategoryzed');

DROP TABLE IF EXISTS `li_comments`;
CREATE TABLE `li_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `nama` varchar(20) NOT NULL,
  `url` varchar(100) NOT NULL,
  `text` text NOT NULL,
  `is_admin` int(1) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `li_comments` (`id`, `article_id`, `datetime`, `nama`, `url`, `text`, `is_admin`, `status`) VALUES
(1,	1,	'2018-10-05 19:27:44',	'Guest',	'http://free.facebook.com',	'Hai, ini komentar petama',	0,	1);

DROP TABLE IF EXISTS `li_file`;
CREATE TABLE `li_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hits` int(11) NOT NULL DEFAULT 0,
  `path` varchar(160) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `li_file` (`id`, `hits`, `path`, `datetime`) VALUES
(1,	0,	'/index.html',	'2018-10-05 19:54:24');

DROP TABLE IF EXISTS `li_navigations`;
CREATE TABLE `li_navigations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `li_navigations` (`id`, `code`) VALUES
(1,	'<a href=\"/\">Home</a>');

DROP TABLE IF EXISTS `li_rolls`;
CREATE TABLE `li_rolls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `url` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `li_rolls` (`id`, `title`, `url`) VALUES
(1,	'Facebook Flex',	'http://free.facebook.com');

DROP TABLE IF EXISTS `li_sessions`;
CREATE TABLE `li_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `li_sessions` (`id`, `key`, `user_id`, `datetime`) VALUES
(1,	'b718cd413dbafa849efba186a966f18d2c2b7a55de253c8a998b85ed5e4c3f52',	1,	'2018-10-05 19:52:39');

DROP TABLE IF EXISTS `li_settings`;
CREATE TABLE `li_settings` (
  `id` int(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `keywords` varchar(500) NOT NULL,
  `description` varchar(160) NOT NULL,
  `limit` int(2) NOT NULL DEFAULT 5,
  `moderate` int(1) NOT NULL DEFAULT 1,
  `timeformat` varchar(20) NOT NULL,
  `stats` int(11) NOT NULL,
  UNIQUE KEY `judul` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `li_settings` (`id`, `name`, `keywords`, `description`, `limit`, `moderate`, `timeformat`, `stats`) VALUES
(1,	'Lingu',	'no,key,words',	'My first project',	5,	0,	'D - m - Y',	0);

DROP TABLE IF EXISTS `li_users`;
CREATE TABLE `li_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `password` varchar(60) NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bio` text NOT NULL,
  `level` tinyint(1) NOT NULL DEFAULT 1,
  `email` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `li_users` (`id`, `user`, `password`, `name`, `bio`, `level`, `email`) VALUES
(1,	'lingu',	'$2y$10$nj8eP8arjDWQT1A2nxf6wuQTk8mEGHK9VXz9sFj8jy1ZdDOAT.GBm',	'ᨒᨙᨕᨚᨓᨖᨛᨐᨘᨉᨗ',	'Programmer',	1,	'wahyulingu@gmail.com');

DROP TABLE IF EXISTS `li_visitors`;
CREATE TABLE `li_visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `datetime` datetime NOT NULL,
  `useragent` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `li_visitors` (`id`, `ip`, `ref`, `datetime`, `useragent`) VALUES
(1,	'0.0.0.0',	'/',	'2018-10-05 19:44:51',	'Android');

-- 2018-10-05 11:59:19
